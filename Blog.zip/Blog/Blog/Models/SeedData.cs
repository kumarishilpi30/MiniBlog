﻿using System;
using Blog.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;


namespace Blog.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext
                (serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            { 
                // Look for any movies.
                if (context.Blog_S.Any())
                {
                    return;   // DB has been seeded
                }

                context.Blog_S.AddRange(
                     new BlogPost
                     {
                         Title = "When Harry Met Sally",
                         CreatedDate = DateTime.Parse("1989-1-11"),
                         Content = "Romantic Comedy",
                         Author = "7.99M"
                     },

                     new BlogPost
                     {
                         Title = "When Harry Met Sally",
                         CreatedDate = DateTime.Parse("1989-1-11"),
                         Content = "Romantic Comedy",
                         Author = "7.99M"
                     }

                     
                );
                context.SaveChanges();
            }
        }
    }
}

