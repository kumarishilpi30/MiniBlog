﻿INSERT INTO Blogs(Id, Title, Body, CreatedDate, Author_Id)
VALUES (1, 'A', 'dgfg', 1-01-2018, 'Sd');